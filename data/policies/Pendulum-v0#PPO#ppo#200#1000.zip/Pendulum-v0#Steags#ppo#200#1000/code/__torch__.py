class ActorNet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  fc : __torch__.torch.nn.modules.linear.Linear
  mu_head : __torch__.torch.nn.modules.linear.___torch_mangle_0.Linear
  sigma_head : __torch__.torch.nn.modules.linear.___torch_mangle_0.Linear
  def forward(self: __torch__.ActorNet,
    x: Tensor) -> Tuple[Tensor, Tensor]:
    x0 = __torch__.torch.nn.functional.relu((self.fc).forward(x, ), False, )
    _0 = torch.tanh((self.mu_head).forward(x0, ))
    mu = torch.mul(_0, 2.)
    sigma = torch.softplus((self.sigma_head).forward(x0, ), 1, 20)
    return (mu, sigma)
  def select_action(self: __torch__.ActorNet,
    state: List[float],
    deterministic: bool=False) -> List[float]:
    state0 = torch.tensor(state, dtype=None, device=None, requires_grad=False)
    _1 = __torch__.torch.autograd.grad_mode.no_grad.__new__(__torch__.torch.autograd.grad_mode.no_grad)
    _2 = (_1).__init__()
    with _1:
      mu, sigma, = (self).forward(state0, )
    act = annotate(List[float], ops.prim.data(mu).tolist())
    return act
