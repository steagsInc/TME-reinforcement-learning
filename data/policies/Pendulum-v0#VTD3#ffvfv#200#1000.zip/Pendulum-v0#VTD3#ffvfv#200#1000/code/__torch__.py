class Actor(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  action_range : int
  input_device : str
  output_device : str
  fc1 : __torch__.torch.nn.modules.linear.Linear
  fc2 : __torch__.torch.nn.modules.linear.___torch_mangle_0.Linear
  fc3 : __torch__.torch.nn.modules.linear.___torch_mangle_1.Linear
  def forward(self: __torch__.Actor,
    state: Tensor) -> Tensor:
    a = torch.relu((self.fc1).forward(state, ))
    a0 = torch.relu((self.fc2).forward(a, ))
    _0 = torch.tanh((self.fc3).forward(a0, ))
    return torch.mul(_0, self.action_range)
  def select_action(self: __torch__.Actor,
    state: List[float],
    deterministic: bool=False) -> List[float]:
    state0 = torch.tensor(state, dtype=None, device=None, requires_grad=False)
    action = (self).forward(state0, )
    act = annotate(List[float], ops.prim.data(action).tolist())
    return act
