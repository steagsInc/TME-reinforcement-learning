class ActorNet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  fc : __torch__.torch.nn.modules.linear.Linear
  mu_head : __torch__.torch.nn.modules.linear.___torch_mangle_0.Linear
  def forward(self: __torch__.ActorNet,
    s: Tensor) -> Tensor:
    x = __torch__.torch.nn.functional.relu((self.fc).forward(s, ), False, )
    _0 = torch.tanh((self.mu_head).forward(x, ))
    return torch.mul(_0, 2.)
  def select_action(self: __torch__.ActorNet,
    state: List[float],
    deterministic: bool=False) -> List[float]:
    state0 = torch.tensor(state, dtype=None, device=None, requires_grad=False)
    action = (self).forward(state0, )
    act = annotate(List[float], ops.prim.data(action).tolist())
    return act
