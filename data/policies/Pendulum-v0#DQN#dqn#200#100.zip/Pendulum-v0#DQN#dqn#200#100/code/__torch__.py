class Net(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  fc : __torch__.torch.nn.modules.linear.Linear
  a_head : __torch__.torch.nn.modules.linear.___torch_mangle_0.Linear
  v_head : __torch__.torch.nn.modules.linear.___torch_mangle_1.Linear
  def forward(self: __torch__.Net,
    x: Tensor) -> Tensor:
    x0 = torch.tanh((self.fc).forward(x, ))
    mean = torch.mean((self.a_head).forward(x0, ), [-1], True, dtype=None)
    a = torch.sub((self.a_head).forward(x0, ), mean, alpha=1)
    v = (self.v_head).forward(x0, )
    return torch.add(a, v, alpha=1)
  def select_action(self: __torch__.Net,
    state: List[float],
    deterministic: bool=False) -> List[float]:
    state0 = torch.tensor(state, dtype=None, device=None, requires_grad=False)
    action = (self).forward(state0, )
    act = annotate(List[float], ops.prim.data(action).tolist())
    return act
